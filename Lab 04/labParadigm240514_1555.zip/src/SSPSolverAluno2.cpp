#include <SubsetSumSolver.h>


/// Aluno2: segunda solucao do aluno = Meet-in-the-Middle OU Branch & Bound
 bool SSPSolverAluno2::solve(const std::vector< long> &input,
                            long value, std::vector< char> &output) {
    
    
    return false;
    
}
