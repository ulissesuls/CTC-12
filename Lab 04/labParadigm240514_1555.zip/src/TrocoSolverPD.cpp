#include <TrocoSolver.h>

void TrocoSolverPD::solve(const std::vector<unsigned int> &denom,unsigned int value, std::vector<unsigned int> &coins) {

    // fills a dummy answer with 2 coins of each denomination    
    coins.resize(denom.size(),2); 
    
    
}//solve
