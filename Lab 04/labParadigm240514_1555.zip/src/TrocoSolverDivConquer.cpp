#include <TrocoSolver.h>

void TrocoSolverDivConquer::solve(const std::vector<unsigned int> &denom,unsigned int value, std::vector<unsigned int> &coins) {

    // fills a dummy answer with 1 coin of each denomination    
    coins.resize(denom.size(),1); 
    
    
}//solve
