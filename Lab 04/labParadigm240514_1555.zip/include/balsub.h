
#include <algorithm>
#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

int balsub(const vector< long> &w,  long c, long &z, std::vector<char> &x) ;
