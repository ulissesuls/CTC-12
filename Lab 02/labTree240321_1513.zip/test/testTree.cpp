#include <gtest/gtest.h>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <stdio.h> 
#include <stdlib.h> 
#include <time.h>
#include <sstream>
#include <cstdio>
#include <algorithm>
//// ces12 lib code
#include <Tick.h> 
#include <Point3.h>
#include <PointReader.h>
#include <IndexPointsAbstract.h>
#include <IndexFactory.h>


/// generates random long, value from 0 to N
long randomUptoN(long N) {
    float ratio = (float)rand() / (float)RAND_MAX;
    return round(ratio * N);
}



// test if vector is sorted and report errors
::testing::AssertionResult isSorted(std::vector<int> &v) {
    bool issorted = true;
    
    if (v.size() > 1)// always sorted if length is 0 or 1
        // move i from the first to the penultimate position
        // stop also if already found it to be not sorted
        for (int i=0; (i <= v.size()-2) && issorted ; i++ )  
            if (v[i] > v[i+1])  issorted = false;
            
    if (issorted)
     return ::testing::AssertionSuccess();
    else {
        std::stringstream ss;
        ss << "vector NOT sorted  " << std::endl << "[ ";
        for (int val : v) 
            ss << val << " " ;
        ss << "]" << std::endl;
        return ::testing::AssertionFailure() << ss.str();
    }
        
}//IsSorted





// test fixture: create data and open file before each test
class TreeTest : public ::testing::Test {
public: 
  // Per-test-suite set-up.
  // Called before the first test in this test suite.
  // Can be omitted if not needed.
  static void SetUpTestSuite() {
    // Use current time as seed for random generator 
    srand(time(0));  
            
    PointReader preader("../data/oakland_part2_complete.asc");
    preader.read(oak);
    
  }

  // Per-test-suite tear-down.
  // Called after the last test in this test suite.
  // Can be omitted if not needed.
  static void TearDownTestSuite() {
    oak.clear(); // if not cleared, next test suite will fill it again
    // and get double the data, repeated
  }

 protected:
  void SetUp() override {
  
    //result_dump.open(FILENAME,std::ios_base::app);
  }
  
  void TearDown() override {
    //result_dump.close();  
  }
  
  
  static std::vector<Point3> oak;
  
};// class TreeTest

std::vector<Point3> TreeTest::oak;

/// parameter functions


////////////// ACTUAL TESTS /////////////////////////

typedef TreeTest SanityTests;
typedef TreeTest OakTests;

#define MILI 1e-3
#define MICRO 1e-6

TEST_F(SanityTests, readAscFile) {
    std::vector<Point3> pp;
    
    PointReader preader("../data/oakland100lines.asc");
    preader.read(pp);
    // check if we have read 100 points
    ASSERT_EQ(pp.size(),100);
        
}//read readAscFile

/// this doesn't test student code. it only tests the lib and the stl based solution
TEST_F(SanityTests, indexFile) {
    std::vector<Point3> pp;
    
    PointReader preader("../data/oakland100lines.asc");
    preader.read(pp);
    
    ASSERT_EQ(pp.size(),100); // we have read 100 points
    
    IndexPointsAbstract* idx = IndexFactory::makeIndex("MMP");
    
    // key to index is only the x coordinate
    for (int i = 0; i < pp.size() ; i++) idx->add( pp[i].x(), i );
    
    ASSERT_EQ(idx->size(),100);
    
    std::vector<long> res; 
    idx->find(res,-16.975,-16.965); // look for the first point
    ASSERT_EQ(res.size(),1); // it is the only point returned
    ASSERT_NEAR(pp[res[0]].x(),-16.97,MILI);
    ASSERT_NEAR(pp[res[0]].y(),-27.84,MILI);
    ASSERT_NEAR(pp[res[0]].z(),  5.72,MILI);
    ASSERT_EQ(pp[res[0]].cat(),1400);
    
    res.clear();
    idx->find(res,-16.76,-16.7); // look for 3 points -16.71 72 75
    ASSERT_EQ(res.size(),3); // check if we got 3 points
    
    delete idx;
}//read readAscFile

// repeat the sanity test with student code
// but with only 100 points, there is no fun
TEST_F(SanityTests, indexFileALU) {
    std::vector<Point3> pp;
    
    PointReader preader("../data/oakland100lines.asc");
    preader.read(pp);
    
    ASSERT_EQ(pp.size(),100);
    
    IndexPointsAbstract* idx = IndexFactory::makeIndex("ALU");
    
    // key to index is only the x coordinate
    for (int i = 0; i < pp.size() ; i++) idx->add( pp[i].x(), i );
    
    ASSERT_EQ(idx->size(),100);
    
    std::vector<long> res; 
    idx->find(res,-16.975,-16.965); // look for the first point, only it
    ASSERT_EQ(res.size(),1);
    ASSERT_NEAR(pp[res[0]].x(),-16.97,MILI);
    ASSERT_NEAR(pp[res[0]].y(),-27.84,MILI);
    ASSERT_NEAR(pp[res[0]].z(),  5.72,MILI);
    ASSERT_EQ(pp[res[0]].cat(),1400);
    
    res.clear();
    idx->find(res,-16.76,-16.7); // look for 3 points -16.71 72 75
    ASSERT_EQ(res.size(),3);
    
    delete idx;
}//read readAscFile

//  reads large file, performs 10 searches, look for randomly chosen points
TEST_F(OakTests, OakReadFile) {
    
    int step_number = 10; // inserts 1/10th of file each time
    long stepsize = oak.size() / step_number;
    IndexPointsAbstract* idx = IndexFactory::makeIndex("ALU");
    
    long next = 0;
    for (int step = 1; step <= step_number ; step++) {
        // add stepsize elements
        for (int i = 0 ; (i < stepsize) && (next < oak.size()) ; i++) {
            idx->add(oak[next].x(),next);
            next++;
        }
        
        long randomptidx = randomUptoN(next-1); 
        std::vector<long> res; 
        
        idx->find(res,oak[randomptidx].x()); // look for the randompoint
        
        ASSERT_GE(res.size(), 0 ) ; // the answer can not be empty
        
        ASSERT_NEAR(oak[res[0]].x(),oak[randomptidx].x(),MILI); // assert we found the same x coord
        
        /// interesting: there are some dozens of points with the same x coord
        //std::cerr << "\n step "<< step <<" looked for: " << oak[randomptidx] << " found : " ; 
        //for (int i = 0 ; i < res.size() ;  i++) std::cerr << oak[res[i]] << " ";
        //std::cerr << "\n";
        
    
    }//for step
    
    delete idx;
    
}//OakReadFile

// reads 1/100th of the file each time
// inserts in index
// searches for a randomly choosen point
// checks if point was found
// measures time for insertion and for search
TEST_F(OakTests, OakByNorm) {
    
    std::ofstream result_dump; // output test results
    result_dump.open("oak_search.csv",std::ios_base::trunc);
    int step_number = 100;
    long stepsize = oak.size() / step_number;
    IndexPointsAbstract* idx = IndexFactory::makeIndex("MMP");
    IndexPointsAbstract* idxaluno = IndexFactory::makeIndex("ALU");
    idx->setTolerance(MICRO); // small tolerance, otherwise many points would be found
    idxaluno->setTolerance(MICRO);
    ces12::Tick tick;
    
    long next = 0;
    for (int step = 1; step <= step_number ; step++) {
        // add stepsize elements
        long old_next = next;
        tick.tickMicro();
        for (long i = 0 ; (i < stepsize) && (next < oak.size()) ; i++) {
            idx->add(oak[next].norm(),next);
            next++;
        }
        float t_ins_stl = (float)tick.tickMicro() / (float)stepsize; // time for insertions
        next = old_next;
        // add stepsize elements
        tick.tickMicro();
        for (long i = 0 ; (i < stepsize) && (next < oak.size()) ; i++) {
            idxaluno->add(oak[next].norm(),next);
            next++;
        }
        float t_ins_aluno = (float)tick.tickMicro()/ (float)stepsize;// time for insertions
        
        
        /// do a number of searches and average times
        std::vector<long> res;
        std::vector<long> resaluno;
        float timeus = 0.0f;
        float timeusaluno = 0.0f;
        int NUMBER_OF_SEARCHES = 10;
        std::vector<long> randomptidx(NUMBER_OF_SEARCHES);
        for ( int i=0 ; i<NUMBER_OF_SEARCHES ; i++) // ids of random points
            randomptidx[i] = randomUptoN(next-1);
        
        
        for (int i=0 ; i<NUMBER_OF_SEARCHES ; i++) { // ids of random points
            res.clear(); resaluno.clear();
            tick.tickMicro();
            idx->find(res, oak[randomptidx[i]].norm()); // look for the randompoint
            timeus += tick.tickMicro();// time for one search
            idxaluno->find(resaluno, oak[randomptidx[i]].norm()); // look for the randompoint
            timeusaluno += tick.tickMicro(); // time for one search
            
            ASSERT_NEAR(oak[res[0]].norm(),oak[randomptidx[i]].norm(),MILI); // assert we found the same norm
            ASSERT_NEAR(oak[resaluno[0]].norm(),oak[randomptidx[i]].norm(),MILI);
            // tolerance here could be MICRO instead of MILI, but it is ok as MILI
        } //endfor searches
        timeus /= NUMBER_OF_SEARCHES; // average time for a search
        timeusaluno /= NUMBER_OF_SEARCHES; // average time for a search
        
        result_dump << step << ", "<< next << ", "<< timeus << ", " << timeusaluno << ", " << t_ins_stl << ", " << t_ins_aluno << std::endl; 
        
        
        /*
        /// need to decrease tolerance to avoid finding many points
        std::cerr << "\n step "<< step <<" looked for: " << oak[randomptidx] << 
            " found "<< res.size() << ": " ; 
        for (int i = 0 ; i < res.size() ;  i++)
            std::cerr << i << ":("<<res[i]<<") " << oak[res[i]] << " ";
        std::cerr << "\n";
        */
        
    
    }//for step
    
    //std::cerr << "\n size oak: " << oak.size()<< " | next: " << next << std::endl;
    
    result_dump.close();
    delete idx; delete idxaluno;
    
}//OakReadFile


// indexes with distance from given point, searches for an interval
// so it accepts a sphere with spherical hole inside
// what is the correct name for this figure? is it a thorus?
// does this for the student index and for the STL one, and writes down both results
TEST_F(OakTests, VoidSphereSelection) {
    
    std::ofstream result_dump; // output test results
    result_dump.open("torusMMP.asc",std::ios_base::trunc);
    std::ofstream result_dump_aluno; // output test results
    result_dump_aluno.open("torusALU.asc",std::ios_base::trunc);
    
    IndexPointsAbstract* idx = IndexFactory::makeIndex("MMP");
    IndexPointsAbstract* idxaluno = IndexFactory::makeIndex("ALU");
    
    ces12::Tick tick;
    
    // near this point there are 1 tree and 2 cars 
    Point3 center(-74,-67,-6,1400);
    // adds all points to both indexes (the whole file)
    for (long i = 0 ; i < oak.size() ; i++ ) {
        idx->add(center.dist(oak[i]),i);
        idxaluno->add(center.dist(oak[i]),i);
    }
    
    std::vector<long> res;
    std::vector<long> resaluno;
    res.clear(); resaluno.clear();
    tick.tickMili();
    idx->find(res, 5,13); // look 
    float timems = tick.tickMili(); // time to search
    idxaluno->find(resaluno, 5,13); // look 
    float timemsaluno = tick.tickMili();// time to search
    
    ASSERT_EQ(resaluno.size(),res.size()); // both must return the same number of points
        
    for (long i = 0 ; i < res.size() ; i++ ) {
        result_dump << oak[res[i]].x() << " " << oak[res[i]].y() << " " << oak[res[i]].z() << std::endl ;
        result_dump_aluno << oak[resaluno[i]].x() << " " << oak[resaluno[i]].y() << " " << oak[resaluno[i]].z() << std::endl ;;
    }
    
    std::cout << " VoidSphere time (ms) MMP: " << timems << " aluno: " << timemsaluno << std::endl;
    
    result_dump.close();
    result_dump_aluno.close();
    delete idx; delete idxaluno;
    
}//OakReadFile



// check if resaluno correspond to all integers from s_begin to s_end, ordered
// as values are float, a suitable comparison with tolerance is performed
::testing::AssertionResult isSearchCorrect(std::vector<long> &resaluno, float s_begin, float s_end) {
    
        //std::stringstream ss;
        //ss << "searching from  " << s_begin << " to " << s_end << std::endl << " [ ";
        //for (float val : resaluno) 
        //    ss << std::fixed << std::setprecision(1) << val << " " ;
        //ss << "]" << std::endl;
        //std::cout << ss.str();
    
    if ( resaluno.size() != round(s_end-s_begin+1) ) {
        std::stringstream ss;
        ss << " wrong size of answer searching from  " << s_begin << " to " << s_end << std::endl << " [ ";
        for (float val : resaluno) 
            ss << std::fixed << std::setprecision(1) << val << " " ;
        ss << "] " ;
        return ::testing::AssertionFailure() << ss.str();
    }
    
    for ( long i = 0; i < resaluno.size() ; i++ ) {
        //std::cout << " r[i]="<< resaluno[i] << " x " << (s_begin + i) << std::endl;
        if ( fabs(resaluno[i] - (s_begin + i) ) > 1E-2 ) { 
            std::stringstream ss;
            ss << " wrong answer searching from  " << s_begin << " to " << s_end << std::endl << " [ ";
            for (float val : resaluno) 
                ss << std::fixed << std::setprecision(1) << val << " " ;
            ss << "] " ;
            return ::testing::AssertionFailure() << ss.str();
        }//if
    }//for
    
    return ::testing::AssertionSuccess();
        
}//isSearchCorrect




TEST_F(SanityTests, AllSearches) {
    IndexPointsAbstract* idx = IndexFactory::makeIndex("MMP");
    IndexPointsAbstract* idxaluno = IndexFactory::makeIndex("ALU");
    
    std::vector<float> dataUp31 =  {16, 8, 24, 4, 12, 20, 26, 28, 2, 6, 10, 14, 18, 22, 30, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31};
        
    for (float i : dataUp31 ) { // add numbers 
        idx->add(i,i);
        idxaluno->add(i,i);
    }//for
    auto minElement = std::min_element(dataUp31.begin(), dataUp31.end());
    auto maxElement = std::max_element(dataUp31.begin(), dataUp31.end());

    std::vector<long> res;
    std::vector<long> resaluno;
    res.clear(); resaluno.clear();
    float tolerance = 1E-4;
    
    for ( long s_begin = *minElement; s_begin <= ((*maxElement)-1) ; s_begin++) {
        for ( long s_end = s_begin+1; s_end <= (*maxElement) ; s_end++) {
            res.clear(); resaluno.clear();
            idx->find(res, s_begin-tolerance,s_end+tolerance); // look 
            idxaluno->find(resaluno, s_begin-tolerance,s_end+tolerance); // look 
            
            ASSERT_TRUE( isSearchCorrect(resaluno , s_begin, s_end) );
            
        }//for
    }//for
    
    
    delete idx; delete idxaluno;    
} //AllSearches
